#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/msg.h>
#include <unistd.h>

struct msgbuf {
  long mtype;
  char mtext[256];
};

void handleError(const char*msg){
    fprintf(stderr, "%s\n", msg);
    exit(EXIT_FAILURE);    
}

void killAProcess(int signo, pid_t pid){
    if(kill(pid, signo) == -1)
        fprintf(stderr, "Kill failed\n");
}

void sendQueue(int queueId, int category, char* str){
    struct msgbuf queueBuff;
    queueBuff.mtype = category;
    strncpy(queueBuff.mtype, str, 256);
    if(msgsnd(queueId, &buff, sizeof(buff.mtext), 0) == -1)
        fprintf(stderr, "Queue failed\n");
}

void sendFifo(){
    if(mkfifo(argv[1],S_IRUSR|S_IWUSR))
        fprintf(stderr, "Fifo failed\n");
    int fd = open(FIFO_PTOC_LOCATION, O_WRONLY);
    close(fd);
}

int main(int argc, char **argv){
    
    // controlla argomenti
    if(argc != 2){
        fprintf(stderr, "Uso errato: %s <pathToFile>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // apre il file
    FILE * cmdFile = fopen(argv[1], "r");
    if(cmdFile == NULL)
        handleError("Il file non esiste");

    // apre la queue
    key_t queueKey = ftok(argv[1], 1);
    if (queueKey == -1) 
        errorHandle("ftok");  int fd = open(FIFO_PTOC_LOCATION, O_WRONLY);
            close(fd);
    
    struct msgbuf queueBuff;
    int queueId = msgget(queueKey, IPC_CREAT | 0777);
    if (queueId == -1) 
        errorHandle("msgget");

    char cmdName[256];
    char buff1[256];
    char buff2[256];


    

    while(fscanf(cmdFile, "%s %s %s\n", cmdName, buff1, buff2) != EOF){
        if(strcmp(cmdName, "kill") == 0){
            int signo = atoi(buff1);
            pid_t pid = atoi(buff2);

            if(signo < 1 || signo > 32){
                fprintf(stderr, "Valore invalido\n");
                continue;
            }
            if(pid < 0){
                fprintf(stderr, "Valore invalido\n");
                continue;
            }

            killAProcess(signo, pid);
        } else if(strcmp(cmdName, "queue") == 0){
            long category = atoi(buff1);
            if(category <= 0){
                fprintf(stderr, "Valore invalido\n");
                continue;
            }
            sendQueue(queueId, category, buff2);

        } else if(strcmp(cmdName, "fifo") == 0){
          
        }

    }

    return 0;
}